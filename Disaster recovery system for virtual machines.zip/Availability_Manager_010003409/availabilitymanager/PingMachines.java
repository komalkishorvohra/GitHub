package availabilitymanager;

public class PingMachines {
	public static boolean pingMachine(String ip) throws Exception {
		String cmd = "";

		if (System.getProperty("os.name").startsWith("Windows")) {
			// For Windows, pings only 3 times
			cmd = "ping -n 3 " + ip;
		} else {
			// For Linux and OSX, pings only 3 times
			cmd = "ping -c 3 " + ip;
		}
		System.out.println();
		System.out.println("Ping "+ ip + "......");
		Process process = Runtime.getRuntime().exec(cmd);
		process.waitFor();		
		return process.exitValue() == 0;
	}
}
