package availabilitymanager;
import java.net.URL;
import com.vmware.vim25.ManagedObjectReference;
import com.vmware.vim25.VirtualMachineSnapshotInfo;
import com.vmware.vim25.VirtualMachineSnapshotTree;
import com.vmware.vim25.mo.InventoryNavigator;
import com.vmware.vim25.mo.ServiceInstance;
import com.vmware.vim25.mo.Task;
import com.vmware.vim25.mo.VirtualMachine;
import com.vmware.vim25.mo.VirtualMachineSnapshot;

public class SnapShotController {

	public static void createSanpshot(VHostEntity vhost) throws Exception {

		ServiceInstance adminSi = new ServiceInstance(new URL(AvailabilityManager.admin),
				AvailabilityManager.userName, AvailabilityManager.password, true);

		//vm = host's object
		VirtualMachine vm = (VirtualMachine) new InventoryNavigator(adminSi.getRootFolder())
		.searchManagedEntity("VirtualMachine", AvailabilityManager.VMs.get(vhost.getIP()));

		if (PingMachines.pingMachine(vhost.getIP())) {
			System.out.println("Ping success.Deleting previous snapshots if any for " + vm.getName() + "......");
			String snapShotname = vm.getName() + "-SnapShot";
			//deleting previous snapshots if any
			try
			{
				VirtualMachineSnapshot vmSnapshot = getSnapshotInTree(vm, snapShotname);
				if(vmSnapshot!=null)
				{
					Task task = vmSnapshot.removeSnapshot_Task(true);
					if(task.waitForTask()==Task.SUCCESS)
					{
						System.out.println("Removed previous host snapshot:" + snapShotname);
					}
				}
			}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			String desc = "A snapshot of " + vm.getName();
			Task task = vm.createSnapshot_Task(snapShotname, desc, false, false);
			if (task.waitForTask() == Task.SUCCESS)
				System.out.println("Host's sanapshot-> "+snapShotname + " was created.");
			else
				System.out.println("Host's sanapshot-> "+snapShotname + " create failure.");
		} else {
			System.out.println("Cannot ping " + vm.getName() + ". Snapshot skipped.");
		}

		adminSi.getServerConnection().logout();
	}


	public static void createSanpshot(VMEntity vm) throws Exception {
		if (!PingMachines.pingMachine(vm.getIP())) {
			System.out.println("Cannot ping " + vm.getName() + ". Snapshot skipped.");
			return;
		}
		System.out.println("Ping success. Deleting previous snapshots if any for " + vm.getName() + "......");
		String snapshotname = vm.getName() + "-SnapShot";
		//deleting previous snapshots if any
		try
		{
			VirtualMachineSnapshot vmsnap = getSnapshotInTree(vm.getVM(), snapshotname);
			if(vmsnap!=null)
			{
				Task task = vmsnap.removeSnapshot_Task(true);
				if(task.waitForTask()==Task.SUCCESS)
				{
					System.out.println("Removed previous vm snapshot:" + snapshotname);
				}
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String desc = "A snapshot of vm " + vm.getName();
		Task task = vm.getVM().createSnapshot_Task(snapshotname, desc, false, false);
		if (task.waitForTask() == Task.SUCCESS)
			System.out.println("VM's sanapshot-> "+snapshotname + " was created.");
		else
			System.out.println("VM's sanapshot-> "+snapshotname + " create failure.");
	}


	private static VirtualMachineSnapshot getSnapshotInTree(
			VirtualMachine vm, String snapName)
	{
		if (vm == null || snapName == null) 
		{
			return null;
		}
		try
		{

			VirtualMachineSnapshotInfo  vInfo = vm.getSnapshot();
			if(vInfo != null){
				VirtualMachineSnapshotTree[] snapTree =
						vm.getSnapshot().getRootSnapshotList();

				if(snapTree!=null)
				{
					ManagedObjectReference mor = findSnapshotInTree(
							snapTree, snapName);
					if(mor!=null)
					{
						return new VirtualMachineSnapshot(
								vm.getServerConnection(), mor);
					}
				}
			}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private static ManagedObjectReference findSnapshotInTree(
			VirtualMachineSnapshotTree[] snapTree, String snapName)
	{
		for(int i=0; i <snapTree.length; i++) 
		{
			VirtualMachineSnapshotTree node = snapTree[i];
			if(snapName.equals(node.getName()))
			{
				return node.getSnapshot();
			} 
			else 
			{
				VirtualMachineSnapshotTree[] childTree = 
						node.getChildSnapshotList();
				if(childTree!=null)
				{
					ManagedObjectReference mor = findSnapshotInTree(
							childTree, snapName);
					if(mor!=null)
					{
						return mor;
					}
				}
			}
		}
		return null;
	}

	public static boolean revertToLastSnapshot(VMEntity vm) throws Exception {
		Task task = vm.getVM().revertToCurrentSnapshot_Task(null);
		if (task.waitForTask() == Task.SUCCESS) {
			System.out.println(vm.getName() + " was reverted to last snapshot.");
			return true;
		} else {
			System.out.println(vm.getName() + " recover failure.");
			return false;
		}
	}

	public static boolean revertToLastSnapshot(VHostEntity vhost) throws Exception {
		ServiceInstance adminSi = new ServiceInstance(new URL(AvailabilityManager.admin),
				AvailabilityManager.userName, AvailabilityManager.password, true);

		//vm = host's object
		VirtualMachine vm = (VirtualMachine) new InventoryNavigator(adminSi.getRootFolder())
		.searchManagedEntity("VirtualMachine", AvailabilityManager.VMs.get(vhost.getIP()));

		VMEntity v = new VMEntity(vm); 
		boolean res = revertToLastSnapshot(v);
		v.powerOn();
		adminSi.getServerConnection().logout();
		return res;
	}
}
