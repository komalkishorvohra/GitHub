package availabilitymanager;
import java.util.ArrayList;
import java.util.List;
import com.vmware.vim25.mo.Alarm;
import com.vmware.vim25.mo.Folder;
import com.vmware.vim25.mo.HostSystem;
import com.vmware.vim25.mo.InventoryNavigator;
import com.vmware.vim25.mo.ManagedEntity;
import com.vmware.vim25.mo.ServiceInstance;


public class VCenterEntity {
	private ServiceInstance vCenter;
	private List<VHostEntity> vHosts;
	private Alarm powerOffAlarm;

	public VCenterEntity(ServiceInstance vCenter) throws Exception {
		this.vCenter = vCenter;
		setHostSystems();
		if (vHosts.size() == 0	)
			throw new NullPointerException("No host available. ");

		powerOffAlarm = AlarmController.createPowerAlarm(vCenter);
	}

	private void setHostSystems() throws Exception {
		this.vHosts = new ArrayList<VHostEntity>();
		Folder vCFolder = vCenter.getRootFolder();
		ManagedEntity[] vHostSystems = new InventoryNavigator(vCFolder)
		.searchManagedEntities("HostSystem");
		if (vHostSystems.length != 0) {
			for (int i = 0; i < vHostSystems.length; i++) {
				this.vHosts.add(new VHostEntity((HostSystem) vHostSystems[i]));
			}
			System.out.println(this.vHosts.size()+" number of hosts present");
			System.out.println("All connected hosts retrieved.");
		} else {
			System.out.println("No host connected.");
		}
	}

	public void createSnapshots() throws Exception {
		while(true) {
			System.out.println();
			for (VHostEntity host : vHosts) {
				host.createSnapshots();
			}
			System.out.printf("Next snapshot after %d seconds..", AvailabilityManager.snapshotInterval);
			System.out.println();
			Thread.sleep(AvailabilityManager.snapshotInterval * 1000);
		}
	}

	public void pingMachine() throws Exception {
		while (true) {
			System.out.println();
			for (int i = 0; i < vHosts.size(); i++) {

				if (!hostAvailability(vHosts.get(i))) {
					// if vhost is unavailable, recover from snapshot
					vHosts.get(i).recover();
					// restart check each vhost in the list
					i = -1;
				}

			} 
			System.out.println(String.format("Next ping task after %d seconds...", AvailabilityManager.mainPingInterval));
			Thread.sleep(AvailabilityManager.mainPingInterval * 1000);
		}
	}

	private boolean hostAvailability(VHostEntity vhost) throws Exception {
		vhost.setVMs();
		List<VMEntity> vmList = vhost.getVMs();
		if (vmList == null) return true;


		for (int i = 0; i < vmList.size(); i++) {
			VMEntity vm = vmList.get(i);

			if (vm.checkPowerOffAlarm(powerOffAlarm)) {
				System.out.println(vm.getVM().getName() + " is powered off.");
				continue;
			}

			if (vm.ping()) {
				System.out.println(vm.getVM().getName() + " is available.");
				continue;
			}

			System.out.println(vm.getVM().getName() + " is unreachable.");

			// vm failure but vhost ping success, recover vm to last state
			if (vhost.ping()) {
				System.out.println(vhost.getIP() + ": host is available.");
				// recover vm by snapshot
				SnapShotController.revertToLastSnapshot(vm);
				vm.powerOn();
				while(vm.getIP() == null);
				i--;
			}
			else {
				System.out.println(vhost.getIP() + ": host ping failure.");
				return false;
			}
		}
		return true;
	}

	public void printStats() throws Exception {
		while (true) {
			while (true) {
				for (VHostEntity host : vHosts)
					host.printStatistic();
				System.out.println(String.format("Next statistic printing after %d seconds...", AvailabilityManager.printInterval));
				System.out.println();
				Thread.sleep(AvailabilityManager.printInterval * 1000);
			}
		}
	}
}


