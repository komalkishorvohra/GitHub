package availabilitymanager;
import java.util.HashMap;
import java.util.Properties;	
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;

import com.vmware.vim25.mo.ServiceInstance;

public class AvailabilityManager {

	public static String vCenterUrl,userName,password,admin;
	public static int numConnectHost,numConnectedHost,snapshotInterval,numPing,
	pingInterval, mainPingInterval,printInterval;
	public static HashMap<String, String> VMs; 

	public static void main(String[] args) throws Exception{

		VMs = new HashMap<String, String>();
		Properties prop = new Properties();
		try
		{
			prop.load(new FileInputStream("Config.properties"));
			vCenterUrl = prop.getProperty("VcenterUrl");
			userName = prop.getProperty("UserName");
			password = prop.getProperty("Password");
			admin = prop.getProperty("Admin");
			snapshotInterval = Integer.parseInt(prop.getProperty("SnapshotInterval"));
			mainPingInterval = Integer.parseInt(prop.getProperty("MainPingInterval"));
			printInterval = Integer.parseInt(prop.getProperty("PrintInterval"));

			//max no of attempts to make to ping
			numPing = Integer.parseInt(prop.getProperty("NumPing"));

			//interval lapse between ping to host when it dosn't respond
			pingInterval = Integer.parseInt(prop.getProperty("PingInterval"));

			//max no of attempts to make to connect to host
			numConnectHost =  Integer.parseInt(prop.getProperty("NumConnectHost"));

			//no of vcenter's hosts
			numConnectedHost =  Integer.parseInt(prop.getProperty("NumConnectedHost"));

			//VMs has ip and host name mapped which is used for creating snapshots on admin for which hosts are vms
			while(numConnectedHost>0)
			{
				VMs.put(prop.getProperty("VHost"+numConnectedHost), prop.getProperty("VHostName"+numConnectedHost));
				numConnectedHost--;
			}

			ServiceInstance si = new ServiceInstance(new URL(vCenterUrl),
					userName, password, true);

			System.out.println("Initial state:");
			VCenterEntity vCenter = new VCenterEntity(si);

			// create snapshot repeatedly for both vms and vhosts
			ThreadController createsnapshot = new ThreadController(vCenter, "Create_Snapshot");
			createsnapshot.start();		

			// ping repeatedly
			ThreadController pingMachine = new ThreadController(vCenter, "Ping_Machine");
			pingMachine.start();

			// print vHosts and vms performance
			ThreadController printStatistics = new ThreadController(vCenter, "Print_Statistics");
			printStatistics.start();
		}	
		catch(IOException ex)
		{
			ex.printStackTrace();	
		}

	}
}
