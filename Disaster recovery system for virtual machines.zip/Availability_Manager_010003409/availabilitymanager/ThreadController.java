package availabilitymanager;

public class ThreadController implements Runnable{
	private VCenterEntity vCenter;
	private String thrdName;
	private Thread t;

	public ThreadController(VCenterEntity vCenter, String taskName) {
		this.vCenter = vCenter;
		thrdName = taskName;
	}

	@Override
	public void run() {
		switch (thrdName) {

		case "Ping_Machine":
			try {
				vCenter.pingMachine();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;

		case "Create_Snapshot":
			try {
				vCenter.createSnapshots();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;

		case "Print_Statistics":
			try {
				vCenter.printStats();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;

		default:
			System.out.println("Wrong thread task name! Choose from heartbeat, backup or printstat");
			break;
		}		
	}

	public void start ()
	{
		System.out.println("\n***** Starting " +  thrdName + " ******");
		if (t == null)
		{
			t = new Thread (this, thrdName);
			t.start ();
		}
	}
}
