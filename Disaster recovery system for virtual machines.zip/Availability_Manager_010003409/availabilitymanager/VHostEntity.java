package availabilitymanager;
import java.util.ArrayList;
import java.util.List;
import com.vmware.vim25.mo.HostSystem;
import com.vmware.vim25.mo.InventoryNavigator;
import com.vmware.vim25.mo.ManagedEntity;
import com.vmware.vim25.mo.Task;
import com.vmware.vim25.mo.VirtualMachine;

public class VHostEntity {
	private HostSystem host;
	private List<VMEntity> vmList;

	public VHostEntity(HostSystem host) throws Exception {
		this.host = host;
		setVMs();
	}

	public void setVMs() throws Exception {
		vmList = new ArrayList<VMEntity>();
		ManagedEntity[] mes = new InventoryNavigator(host)
		.searchManagedEntities("VirtualMachine");
		if (mes == null) return;	
		for (int i = 0; i < mes.length; i++) {
			vmList.add(new VMEntity((VirtualMachine) mes[i]));
		}
	}

	public void createSnapshots() throws Exception {
		if (vmList == null)
			return;
		SnapShotController.createSanpshot(this);
		for (int i = 0; i < vmList.size(); i++)
			SnapShotController.createSanpshot(vmList.get(i));
	}

	public String getIP() {
		return host.getName();
	}

	public List<VMEntity> getVMs() {
		return vmList;
	}

	public boolean ping() throws Exception {
		int time = 0;
		if(getIP()!=null)
		{	
			while (!PingMachines.pingMachine(getIP())) {						
				time++;
				if (time >= AvailabilityManager.numPing)
					return false;
				else 
					Thread.sleep(AvailabilityManager.pingInterval * 1000);
			}
		}
		return true;
	}

	public void recover() throws Exception {
		if (SnapShotController.revertToLastSnapshot(this)) {
			System.out.println("Host is recovered from snapshot. ");	
			Thread.sleep(1000);
			reconnect();
		}
	}

	// reconnect host
	public void reconnect() throws Exception {
		int n = 0;
		//attempts to reconnect
		while (n < AvailabilityManager.numConnectHost) {
			n++;
			Task task = host.reconnectHost_Task(null);
			System.out.println("Reconnecting host " + host.getName() + "......");
			Thread.sleep(50*1000);

			if (task.waitForTask() == Task.SUCCESS) {
				System.out.println("Reconnect host success");
				for (VMEntity vm : vmList) {
					vm.powerOn();
					while(vm.getIP() == null);
				}
				return;
			} else {
				System.out.println(task.getTaskInfo().getError()
						.getLocalizedMessage());
			}
		}
		return;
	}

	public void printStatistic() throws Exception {
		System.out.println();
		System.out.println("vHost: " + getIP());
		System.out.println("********VMs********");

		if (vmList == null)
			return;
		for (int i = 0; i < vmList.size(); i++)
			vmList.get(i).printStatistic();
		;
		System.out.println("-------------------------");
	}
}
