package availabilitymanager;

import com.vmware.vim25.AlarmSetting;
import com.vmware.vim25.AlarmSpec;
import com.vmware.vim25.StateAlarmExpression;
import com.vmware.vim25.StateAlarmOperator;
import com.vmware.vim25.mo.Alarm;
import com.vmware.vim25.mo.AlarmManager;
import com.vmware.vim25.mo.ManagedEntity;
import com.vmware.vim25.mo.ServiceInstance;

public class AlarmController {
	//create alarm on the datacenter, which can be applied to all sub-vms
	public static Alarm createPowerAlarm(ServiceInstance si) throws Exception{

		ManagedEntity[] dcs = si.getRootFolder().getChildEntity();
		
		AlarmManager alarmController = si.getAlarmManager();
		AlarmSpec alarmSpecifications = new AlarmSpec();
		StateAlarmExpression alarmExpression = createStateAlarmExpression();
	
	    alarmSpecifications.setAction(null);
	    alarmSpecifications.setExpression(alarmExpression);
	    alarmSpecifications.setName("Virtual Machine PowerOff State Alarm");
	    alarmSpecifications.setDescription("Monitor VM state and alarm when VM powers off");
	    alarmSpecifications.setEnabled(true);    
	    
	    AlarmSetting alarmsetting = new AlarmSetting();
	    alarmsetting.setReportingFrequency(0); //the alarm is allowed to trigger as often as possible
	    alarmsetting.setToleranceRange(0);
	    
	    alarmSpecifications.setSetting(alarmsetting);
	    Alarm[] alarms = alarmController.getAlarm(dcs[0]);
	    for (Alarm alarm : alarms) {
	    	if (alarm.getAlarmInfo().getName().equals(alarmSpecifications.getName()))
	    		alarm.removeAlarm();
	    }
	    Alarm alarm = alarmController.createAlarm(dcs[0], alarmSpecifications);
	    System.out.println("PowerOff State Alarm created!");
	    Thread.sleep(2000);
	    return alarm;
	}
	
	//set alarm to yellow when the vm powered off
	private static StateAlarmExpression createStateAlarmExpression() {
		StateAlarmExpression alarmExpression = new StateAlarmExpression();
		alarmExpression.setType("VirtualMachine");
		alarmExpression.setStatePath("runtime.powerState");
		alarmExpression.setOperator(StateAlarmOperator.isEqual);
		alarmExpression.setYellow("poweredOff");
		return alarmExpression;
	}
}
