package availabilitymanager;
import com.vmware.vim25.AlarmState;
import com.vmware.vim25.VirtualMachineQuickStats;
import com.vmware.vim25.mo.Alarm;
import com.vmware.vim25.mo.Task;
import com.vmware.vim25.mo.VirtualMachine;

public class VMEntity {
	private VirtualMachine vm;

	public VMEntity(VirtualMachine vm) {
		this.vm = vm;
	}

	public String getIP() {

		return vm.getGuest().getIpAddress();
	}

	public String getName() {
		return vm.getName();
	}

	public VirtualMachine getVM() {
		return vm;
	}

	public boolean checkPowerOffAlarm(Alarm alarm) {
		AlarmState[] as = vm.getTriggeredAlarmState();
		if (as == null)
			return false;
		for (AlarmState state : as) {
			// if the vm has a poweroff alarm, return true
			if (alarm.getMOR().getVal().equals(state.getAlarm().getVal()))
				return true;
		}
		return false;
	}


	public boolean ping() throws Exception {
		int time = 0;
		while (!PingMachines.pingMachine(getIP())) {						
			time++;
			if (time >= AvailabilityManager.numPing)
				return false;
			else 
				Thread.sleep(AvailabilityManager.pingInterval * 1000);
		}
		return true;
	}

	public void powerOn() throws Exception {
		Task task = vm.powerOnVM_Task(null);
		System.out.println(vm.getName() + " is powering on...");
		if (task.waitForTask() == Task.SUCCESS)
		{
			Thread.sleep(5000);
			System.out.println(vm.getName() + " is running now.");
		}
	}

	public void printStatistic() throws Exception {

		VirtualMachineQuickStats stats = vm.getSummary().getQuickStats();
		System.out.println("\nName: " + vm.getName());
		System.out.println("Guest OS: "
				+ vm.getSummary().getConfig().guestFullName);
		System.out.println("VM Version: " + vm.getConfig().version);
		System.out.println("CPU Usage: " + stats.overallCpuUsage
				+ " vCPU");
		System.out.println("Memory: " + vm.getConfig().getHardware().memoryMB
				+ " MB");
		System.out.println("Memory Usage: " + stats.getHostMemoryUsage()
				+ " MB");
		System.out.println("IP Addresses: " + vm.getGuest().getIpAddress());
		System.out.println("State: " + vm.getGuest().guestState);
	}
}
