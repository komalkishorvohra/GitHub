import java.io.*;
import java.net.*;
import javax.swing.*;
import java.awt.event.*;

class Client extends JFrame implements ActionListener
{

	JLabel lblstr=new JLabel("Enter the string");
	JTextArea txtres=new JTextArea();

	JTextField txtstr=new JTextField();
	JButton btnok=new JButton("Ok");
	String s;
	public Client()
	{
		setVisible(true);
		setSize(500,500);
		setLayout(null);
		lblstr.setBounds(10,10,150,20);
		txtstr.setBounds(10,40,100,50);
		btnok.setBounds(10,120,300,60);
		txtres.setBounds(10,200,300,250);
		txtres.setEditable(false);
		txtres.setRows(5);
		txtres.setLineWrap(true);
		add(lblstr);
		add(txtstr);

		add(btnok);
		add(txtres);
		btnok.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		String  command=e.getActionCommand();
		if(command.equals("Ok"))
		{
		try
			   {
		    Socket skt = new Socket("127.0.0.1", 8900);
	     InputStream sin = skt.getInputStream();
		     OutputStream sout = skt.getOutputStream();
		     DataInputStream din = new DataInputStream(sin);
		     DataOutputStream dout = new DataOutputStream(sout);

		     BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		    dout.writeUTF(txtstr.getText());
	    txtres.setText(din.readUTF());

	    //System.out.println("Data : " + s) ;
	    skt.close();

	   }
	   catch(Exception ex)
	   {
		    ex.printStackTrace();
	   }

	}
}
 public static void main(String args[])
 {
   new Client();
 }
}