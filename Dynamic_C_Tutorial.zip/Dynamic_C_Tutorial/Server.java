/*
Server
*/

import java.net.*;

class Server implements Runnable
{
 ServerSocket svr;
 int portNo;
 Thread t;
 boolean flag;

 Server(int p) throws Exception
 {
   portNo = p;
   svr = new ServerSocket(portNo);
   flag = true;
   t = new Thread(this);
   t.start();
 }
 public void run()
 {
   getConnections();
 }

 void getConnections()
 {
  try
  {
    Socket temp;
    while(flag == true)
    {
      System.out.println("before accept");
      temp = svr.accept();
      System.out.println("after accept");
      ProcessConn pconn = new ProcessConn(temp);
    }//while
    svr.close();
  }
  catch(Exception ex)
  {
     ex.printStackTrace();
  }
 }
 public static void main(String args[])
 {
  try
  {
     Server s = new Server(8900);
  }
  catch(Exception ex)
  {
     ex.printStackTrace();
  }

 }
}