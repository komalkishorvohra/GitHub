import java.net.*;
import java.io.*;
class ProcessConn extends Thread
{
 Socket skt;  
 ProcessConn(Socket temp)
 {
    skt = temp;
    start();//activate the thread
 }

 public void run()
 {
  processskt();
 }

 void processskt()
 {
  try
  {
    InputStream sin = skt.getInputStream();
    OutputStream sout = skt.getOutputStream(); 
    DataInputStream din = new DataInputStream(sin);
    DataOutputStream dout = new DataOutputStream(sout);
	String onerow;
    String s = din.readUTF();
   s="select * from data where token LIKE '" + s+"'";
  

try
  {
    DBH dbh1 = new DBH();
  onerow=dbh1.executeQuery(s);
   dout.writeUTF(onerow);
      dbh1.close();    
  }//try
  catch(Exception ex)
  {
    System.out.println("Err : " + ex);
  }

    skt.close();
  } 
  catch(Exception ex)
  {
     ex.printStackTrace();
  }

}
}