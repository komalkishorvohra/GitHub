import java.sql.*;
import java.io.*;

class DBH
{
 Connection conn;
 Statement stmt;

 DBH() throws Exception
 {
   //make a connection
   //load the jdbc-odbc drivers in memory
   Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
   //get the Connection object
   conn = DriverManager.getConnection("jdbc:odbc:data");

  //create a Statment
  stmt = conn.createStatement();
 }

String executeQuery(String sql) throws Exception
 {//for stmt that return data
String one="";
   ResultSet rs = stmt.executeQuery(sql);
   int i, cols;
   ResultSetMetaData rsmd = rs.getMetaData();

   //find the no of cols
   cols = rsmd.getColumnCount();

rs.next();
      for(i = 1; i<= cols; i++)
      {
one=one+":"+rs.getString(i);
         //System.out.print(rs.getString(i) + "  " );

      }

   rs.close();
return one;
 }


 void close() throws Exception
 {
    conn.close();
 }
}