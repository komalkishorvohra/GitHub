class EHandling1
{
 int a, b, c;
 void set(String arr[]) throws NumberFormatException, ArrayIndexOutOfBoundsException
 {
    a = Integer.parseInt(arr[0]);
    b = Integer.parseInt(arr[1]);
 }

 void divide() throws ArithmeticException
 {
     c = a/b;
 }

 void disp()
 {
    System.out.println("a : " + a);
    System.out.println("b : " + b);
    System.out.println("c : " + c);
 }

 public static void main(String args[])
 {  
   try
   {
    EHandling1 e1 = new EHandling1();
    e1.set(args);
    e1.divide();
    e1.disp();
   }
   catch(NumberFormatException ex)
   {
       System.out.println("Invalid Data");
   }
   catch(ArithmeticException ex)
   {
       System.out.println("ans : Infinity");
   }
   catch(ArrayIndexOutOfBoundsException ex)
   {
       System.out.println("Data Missing");
   }
   finally
   {
      System.out.println("in finally");
   }
  System.out.println("prg ends ");
 }//main
}

/*
There are cases when a fn
may raise execptions but
doesnt handle them.

And exception handling is to be
delegated to the caller of the fn.

Such cases are resolved using
"throws" keyword

throws statement tells jvm that
current fn may raise an exception
by handling is to be done by the
caller of the fn.

*/