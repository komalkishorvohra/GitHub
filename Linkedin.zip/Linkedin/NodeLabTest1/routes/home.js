var ejs = require("ejs");
//var mysql = require('./mysql');
var mysql = require('./mySQLConnectionPool');

var LocalStorage = require('node-localstorage').LocalStorage,
localStorage = new LocalStorage('./scratch');
var Member_userId;

function signin(req,res) {

	ejs.renderFile('./views/signin.ejs',function(err, result) {
	   // render on success
	   if (!err) {
	            res.end(result);
	   }
	   // render or error
	   else {
	            res.end('An error occurred');
	            console.log(err);
	   }
   });
}


function afterSignIn(req,res)
{
	// check user already exists
	var getUser="select * from user_info where user_email='" + req.param("username")
	+ "' AND user_password='" + req.param("password") + "'";
	console.log("Query is:"+getUser);
	
	mysql.fetchData(function(err,results){
		if(err){
			throw err;
			}
		else 
		{
			if(results.length > 0){
				console.log("valid Login");
				//recording login time
				localStorage.setItem('currentLoginTime', Date());
				//res.redirect('/successSignIn');
				var userEmail= results[0].user_email;
				exports.userName=userEmail;
				console.log(userEmail);
				var userid= results[0].user_id;
				console.log(userid);
				exports.userid=userid;
				req.session.userid=userid;
				res.send({"login":"Success"});
				}
			else {    
				
				console.log("Invalid Login");
				res.send({"login":"Fail"});
			}
		}  
	},getUser);
}


function successLogin(req,res)
{
	
	ejs.renderFile('./views/successLogin.ejs',function(err, result) {
  		// render on success
        if (!err) {
            res.end(result);
        }
        // render or error
        else {
            res.end('An error occurred');
            console.log(err);
        }
	 });
}




function loadProfile(req,res)
{
	
	var lastLoginTime = (typeof(lastLoginTime) == "undefined") ? localStorage.getItem('currentLoginTime') :lastLoginTime;
	
	
	var getUserDetails="select * from user_info where user_id='" +req.session.userid
	+ "'";
	console.log("User Query is:"+getUserDetails);
	
	//extract user education
	var getEducation="select * from user_education where user_id='" +req.session.userid
	+ "'";
	console.log("Education Query is:"+getEducation);
	
	var getExperience="select * from user_experience where user_id='" +req.session.userid
	+ "'";
	console.log("Experience Query is:"+getExperience);
	
	var getSkill="select * from user_skills where user_id='" +req.session.userid
	+ "'";
	console.log("Skill Query is:"+getSkill);
	
	var getConnRequests="select * from user_info where user_id IN (select conn_id from user_connections where user_id= '" +req.session.userid
	+ "' and status='N')";
	console.log("Connection Request Query is:"+getConnRequests);


	
	mysql.fetchData(function(err,results){
		if(err){
			throw err;
			}
		else 
		{
			if(results.length > 0){
				console.log("user info fetched successfully");
				fullName = results[0].user_fname + " " + results[0].user_lname;
				summary = results[0].summary;
				exports.fullName=fullName;
				exports.summary=summary;
				var lastLoginTime = (typeof(lastLoginTime) == "undefined") ? localStorage.getItem('currentLoginTime') :lastLoginTime;
				
				
				
				mysql.fetchData(function(err,eduResults) {

					if (!err) {
							
						mysql.fetchData(function(err,expResults) {

							if (!err) {
								mysql.fetchData(function(err,skillResults) {

									if (!err) {
					
										mysql.fetchData(function(err,connRequestResults) {

											if (!err) {
						res.send({"lastLoginTime":JSON.stringify(lastLoginTime),"fullName":JSON.stringify(fullName),"summary":JSON.stringify(summary),  "eduResults": JSON.stringify(eduResults), "expResults": JSON.stringify(expResults),"skillResults": JSON.stringify(skillResults), "connRequestResults": JSON.stringify(connRequestResults) });	
													
												
													//res.end(result);
												}
												// render or error
												else {
													res.end('An error occurred');
													console.log(err);
												}
											}, getConnRequests);
						
										
											//res.end(result);
										}
										// render or error
										else {
											res.end('An error occurred');
											console.log(err);
										}
									}, getSkill);
								}
								// render or error
								else {
									res.end('An error occurred');
									console.log(err);
								}
							}, getExperience);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getEducation);
				
				
				}
			else {    
				
				console.log("user info fetch unsuccessfull");
		}
		}  
	},getUserDetails);

}





function editSummary(req,res)
{
	
	// update user's summary
		var query = "update user_info set user_info.summary = '" + req.param("summary")+"' where user_id= '"+req.session.userid+"'";
		console.log("Query is:"+query);
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				
					console.log("summary updated successfully");
					summary = req.param("summary");
					exports.summary=summary;
								
					res.send({"summary":"summary"});
				}
			 
		},query);
	
	
}



function editEducation(req,res)
{
	console.log(req.param("eduIdToUpdate"));
	console.log(req.param("eduUniversityToUpdate"));
	console.log(req.param("eduDegreeToUpdate"));
	
	// update user's education
		var query = "update user_education set user_education.university_name = '" + req.param("eduUniversityToUpdate")+"' , user_education.degree = '" + req.param("eduDegreeToUpdate")+"' where ed_id= '"+req.param("eduIdToUpdate")+"'";
		console.log("Query is:"+query);
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				
					console.log("Education updated successfully");
				
								
					res.send({"Updation":"Successfull"});
				}
			 
		},query);
	
	
}


function addEducation(req,res)
{
	
	
	// add education
		var query = "insert into user_education values('','"+req.session.userid+"','"+req.param("newUniversity")+"','"+req.param("newDegree")+"')";
		console.log("Query is:"+query);
	
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				var getNewEducation="select * from user_education where user_id='" +req.session.userid+ "'";
				console.log("Education Query is:"+getNewEducation);
				
				mysql.fetchData(function(err,eduResults) {

					if (!err) {
						console.log("Education added successfully");	
						res.send({"addedEduResults": JSON.stringify(eduResults) });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getNewEducation);
				}
			 
		},query);
}


function deleteEducation(req,res)
{

	// delete education
		var query = "delete from user_education where ed_id = '"+req.param("eduIdToDelete")+"'";
		console.log("Query is:"+query);
	
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				var getNewEducation="select * from user_education where user_id='" +req.session.userid+ "'";
				console.log("Education Query is:"+getNewEducation);
				
				mysql.fetchData(function(err,eduResults) {

					if (!err) {
						console.log("Education deleted successfully");	
						res.send({"modifiedEduResults": JSON.stringify(eduResults) });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getNewEducation);
				}
			 
		},query);
}






function editExperience(req,res)
{
	console.log(req.param("expIdToUpdate"));
	console.log(req.param("expCompanyToUpate"));
	console.log(req.param("expDurationToUpdate"));
	
	// update user's education
		var query = "update user_experience set company_name = '" + req.param("expCompanyToUpate")+"' , duration = '" + req.param("expDurationToUpdate")+"' where exp_id= '"+req.param("expIdToUpdate")+"'";
		console.log("Query is:"+query);
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				
					console.log("Experience updated successfully");
				
								
					res.send({"Updation":"Successfull"});
				}
			 
		},query);
	
	
}


function addExperience(req,res)
{
	
	
	// add education
		var query = "insert into user_experience values('','"+req.param("newCompany")+"','"+req.param("newDuration")+"','"+req.session.userid+"')";
		console.log("Query is:"+query);
	
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				var getNewExperience="select * from user_experience where user_id='" +req.session.userid+ "'";
				console.log("Experience Query is:"+getNewExperience);
				
				mysql.fetchData(function(err,expResults) {

					if (!err) {
						console.log("Experience added successfully");	
						res.send({"addedExpResults": JSON.stringify(expResults) });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getNewExperience);
				}
			 
		},query);
}


function deleteExperience(req,res)
{

	// delete education
		var query = "delete from user_experience where exp_id = '"+req.param("expIdToDelete")+"'";
		console.log("Query is:"+query);
	
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				var getNewExperience="select * from user_experience where user_id='" +req.session.userid+ "'";
				console.log("Experience Query is:"+getNewExperience);
				
				mysql.fetchData(function(err,expResults) {

					if (!err) {
						console.log("Experience deleted successfully");	
						res.send({"modifiedExpResults": JSON.stringify(expResults) });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getNewExperience);
				}
			 
		},query);
}



function editSkill(req,res)
{
	console.log(req.param("skillIdToUpdate"));
	console.log(req.param("skillDescriptionToUpdate"));
	console.log(req.param("skillRatingsToUpdate"));
	
	// update user's education
		var query = "update user_skills set description = '" + req.param("skillDescriptionToUpdate")+"' , num_of_endorsement = '" + req.param("skillRatingsToUpdate")+"' where skill_id= '"+req.param("skillIdToUpdate")+"'";
		console.log("Query is:"+query);
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				
					console.log("Skill updated successfully");
				
								
					res.send({"Updation":"Successfull"});
				}
			 
		},query);
	
	
}


function addSkill(req,res)
{
	
	
	// add education
		var query = "insert into user_skills values('','"+req.session.userid+"','"+req.param("newDescription")+"','"+req.param("newRatings")+"')";
		console.log("Query is:"+query);
	
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				var getNewSkill="select * from user_skills where user_id='" +req.session.userid+ "'";
				console.log("Skill Query is:"+getNewSkill);
				
				mysql.fetchData(function(err,skillResults) {

					if (!err) {
						console.log("Skill added successfully");	
						res.send({"addedSkillResults": JSON.stringify(skillResults) });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getNewSkill);
				}
			 
		},query);
}


function deleteSkill(req,res)
{

	// delete education
		var query = "delete from user_skills where skill_id = '"+req.param("skillIdToDelete")+"'";
		console.log("Query is:"+query);
	
		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				var getNewSkill="select * from user_skills where user_id='" +req.session.userid+ "'";
				console.log("Skill Query is:"+getNewSkill);
				
				mysql.fetchData(function(err,skillResults) {

					if (!err) {
						console.log("Skill deleted successfully");	
						res.send({"modifiedSkillResults": JSON.stringify(skillResults) });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getNewSkill);
				}
			 
		},query);
}





function acceptConnectionRequest(req,res)
{
	//change status of connection
	var query = "update user_connections set status = 'Y' where user_id= '"+req.session.userid+"' and conn_id= '"+req.param("connIdToAccept")+"'";
	console.log("Query is:"+query);

		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				var getNewConnRequests="select * from user_info where user_id IN (select conn_id from user_connections where user_id= '" +req.session.userid
				+ "' and status='N')";
				console.log("Connection Request Query is:"+getNewConnRequests);
				
				mysql.fetchData(function(err,modifiedconnRequestResults) {

					if (!err) {
						console.log("Connections fetched successfully");	
						res.send({"modifiedconnRequestResults": JSON.stringify(modifiedconnRequestResults) });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getNewConnRequests);
				}
			 
		},query);
}



function rejectConnectionRequest(req,res)
{
	//change status of connection
	var query = "delete from user_connections where user_id= '"+req.session.userid+"' and conn_id= '"+req.param("connIdToReject")+"'";
	console.log("Query is:"+query);

		
		mysql.fetchData(function(err,results){
			if(err){
				throw err;
				}
			else 
			{
				var getNewConnRequests="select * from user_info where user_id IN (select conn_id from user_connections where user_id= '" +req.session.userid
				+ "' and status='N')";
				console.log("Connection Request Query is:"+getNewConnRequests);
				
				mysql.fetchData(function(err,modifiedconnRequestResults) {

					if (!err) {
						console.log("Connections fetched successfully");	
						res.send({"modifiedconnRequestResults": JSON.stringify(modifiedconnRequestResults) });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, getNewConnRequests);
				}
			 
		},query);
}




function searchMember(req,res)
{
	
	var member_fname = req.param("f_name");
	exports.member_fname=member_fname;
	console.log(member_fname);
	var member_lname = req.param("l_name");
	exports.member_lname=member_lname;
	console.log(member_lname);
	var query = "select user_id from user_info where user_fname='" +member_fname+ "' or user_lname = '"+member_lname+"'";
	console.log("Query is:"+query);
	
	mysql.fetchData(function(err,results){
		if(err){
			throw err;
						}
		else if(results.length > 0){
		
			
				Member_userId=results[0].user_id;
				console.log(Member_userId);
				exports.Member_userId=Member_userId;
				res.send({"Member":"Found"});
			}
		else {    
			
			console.log("Member not found");
			res.send({"Member":"Not Found"});
		}
		 
	},query);
}

function showMember(req,res)
{
	ejs.renderFile('./views/memberProfile.ejs',function(err, result) {
  		// render on success
        if (!err) {
            res.end(result);
        }
        // render or error
        else {
            res.end('An error occurred');
            console.log(err);
        }
	 });
	console.log("In show member");
	
}



function showMemberProfile(req,res)
{
var getUserDetails="select * from user_info where user_id='" +Member_userId
+ "'";
console.log("User Query is:"+getUserDetails);

//extract user education
var getEducation="select * from user_education where user_id='" +Member_userId
+ "'";
console.log("Education Query is:"+getEducation);

var getExperience="select * from user_experience where user_id='" +Member_userId
+ "'";
console.log("Experience Query is:"+getExperience);

var getSkill="select * from user_skills where user_id='" +Member_userId
+ "'";
console.log("Skill Query is:"+getSkill);

var getStatus="select status from user_connections where conn_id='" +Member_userId
+ "' and user_id = '"+req.session.userid+"'";
console.log("Skill Query is:"+getStatus);

mysql.fetchData(function(err,results){
	if(err){
		throw err;
		}
	else 
	{
		if(results.length > 0){
			console.log("user info fetched successfully");
			memberFullName = results[0].user_fname + " " + results[0].user_lname;
			memberSummary = results[0].summary;
			
			mysql.fetchData(function(err,eduResults) {

				if (!err) {
						
					mysql.fetchData(function(err,expResults) {

						if (!err) {
							mysql.fetchData(function(err,skillResults) {

								if (!err) {
				
								
									
					//res.send({"fullName":JSON.stringify(memberFullName),"summary":JSON.stringify(memberSummary),  "eduResults": JSON.stringify(eduResults), "expResults": JSON.stringify(expResults),"skillResults": JSON.stringify(skillResults)});	
									mysql.fetchData(function(err,statusResults) {

										if (!err) {
											if(statusResults.length > 0){
										/*	console.log(JSON.stringify(eduResults));
											console.log(JSON.stringify(expResults));
											console.log(JSON.stringify(skillResults));*/
											console.log("if")
											var status = statusResults[0].status;
							res.send({"fullName":JSON.stringify(memberFullName),"summary":JSON.stringify(memberSummary),  "eduResults": JSON.stringify(eduResults), "expResults": JSON.stringify(expResults),"skillResults": JSON.stringify(skillResults),"statusResults": JSON.stringify(status)});	
											}
											else
												{
												console.log("else");
												var status = "";
												res.send({"fullName":JSON.stringify(memberFullName),"summary":JSON.stringify(memberSummary),  "eduResults": JSON.stringify(eduResults), "expResults": JSON.stringify(expResults),"skillResults": JSON.stringify(skillResults),"statusResults": JSON.stringify(status)});
												}
											}
											// render or error
											else {
												res.end('An error occurred');
												console.log(err);
											}
										}, getStatus);		
									}
									// render or error
									else {
										res.end('An error occurred');
										console.log(err);
									}
								}, getSkill);
							}
							// render or error
							else {
								res.end('An error occurred');
								console.log(err);
							}
						}, getExperience);
					}
					// render or error
					else {
						res.end('An error occurred');
						console.log(err);
					}
				}, getEducation);
			
			
			}
		else {    
			
			console.log("user info fetch unsuccessfull");
	}
	}  
},getUserDetails);

}



function sendRequest(req,res)
{
	
	
	// add education
		var query = "insert into user_connections values('','"+Member_userId+"','"+req.session.userid+"','N')";
		console.log("Query is:"+query);
	
		

				
				mysql.fetchData(function(err,Results) {

					if (!err) {
						console.log("Connection Request sent successfully");	
						res.send({"ConnectionRequest": "sent" });	
							//res.end(result);
						}
						// render or error
						else {
							res.end('An error occurred');
							console.log(err);
						}
					}, query);
				
}



function failLogin(req,res)
{
	ejs.renderFile('./views/failLogin.ejs',function(err, result) {
        // render on success
        if (!err) {
            res.end(result);
        }
        // render or error
        else {
            res.end('An error occurred');
            console.log(err);
        }
    });
}

function signout(req,res) {
	
	if(req.session.userid){
		req.session.destroy();
		//saving last login time before logout
		var lastLoginTime = localStorage.getItem('currentLoginTime');
		console.log("last : "+lastLoginTime);
		localStorage.setItem('lastLoginTime', lastLoginTime);
		exports.lastLoginTime=lastLoginTime;
		res.send(JSON.stringify({"logout":"Session Destroyed"}));
	}else{
		res.send(JSON.stringify({"logout":"No Session Data to DELETE"}));
	}
}

function connection(req,res)
{
	
	ejs.renderFile('./views/connections.ejs',function(err, result) {
  		// render on success
        if (!err) {
            res.end(result);
        }
        // render or error
        else {
            res.end('An error occurred');
            console.log(err);
        }
	 });
}


function loadConnections(req,res)
{
var getConnections = "select * from user_info where user_id IN (select conn_id from user_connections where user_id = '" +req.session.userid+ "' and status='Y')";	

console.log("Connections Query is:"+getConnections);

mysql.fetchData(function(err,connResults) {

	if (!err) {
		console.log("Connections fetched successfully");	
		res.send({"connResults": JSON.stringify(connResults) });	
			//res.end(result);
		}
		// render or error
		else {
			res.end('An error occurred');
			console.log(err);
		}
	}, getConnections);
}

exports.signin=signin;
exports.signout=signout;
exports.afterSignIn=afterSignIn;
exports.loadProfile=loadProfile;
exports.successLogin=successLogin;
exports.failLogin=failLogin;
exports.editSummary=editSummary;
exports.deleteEducation=deleteEducation;
exports.editEducation=editEducation;
exports.addEducation=addEducation;
exports.deleteExperience=deleteExperience;
exports.editExperience=editExperience;
exports.addExperience=addExperience;
exports.deleteSkill=deleteSkill;
exports.editSkill=editSkill;
exports.addSkill=addSkill;
exports.connection=connection;
exports.loadConnections=loadConnections;
exports.acceptConnectionRequest=acceptConnectionRequest;
exports.rejectConnectionRequest=rejectConnectionRequest;
exports.searchMember=searchMember;
exports.showMember=showMember;
exports.showMemberProfile=showMemberProfile;
exports.sendRequest=sendRequest;