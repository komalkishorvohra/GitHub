var ejs = require("ejs");
var mysql = require('./mysql');
/*var userid= require('./home');*/

exports.insertUser = function(req, res) {
	
	var getUser="select * from user_info where user_email='" + req.param("email")
	+ "'";
	console.log("Query is:"+getUser);
	
	mysql.fetchData(function(err,results){
		if(err){
			throw err;
			}
		else 
		{
			if(results.length > 0){
				console.log("Already Registered");
				
				//res.redirect('/successSignIn');
				res.send({"registeration":"Already Registered"});
				}
			else {    
				
					var query = "insert into user_info values(null,'" + req.param("first_name")
		+ "','" + req.param("last_name") + "','" + req.param("email")
		+ "','" + req.param("password") + "','')";

var fullname=req.param("first_name") + " " + req.param("last_name")
console.log("Query is:" + query);

mysql.fetchData(function(err, results) {
	if (err) {
		throw err;
	} else {
		console.log("new user registered");
		res.send({"registeration":"Successfull"});
	}
}, query);
			}
		}  
	},getUser);
	
}