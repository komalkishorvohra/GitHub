var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
   , session = require('express-session')
  , test = require('./routes/test')
  , home = require('./routes/home')
  , signup = require('./routes/signup')
  , path = require('path');

var app = express();

app.use(express.cookieParser());
app.use(express.session({ secret: 'keyboard cat'}));

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));


// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

app.get('/', home.signin);

app.get('/signin', home.signin);
app.post('/signin', home.afterSignIn);
app.get('/successLogin', home.successLogin);
app.get('/loadProfile', home.loadProfile);
app.get('/failLogin', home.failLogin);
app.post('/insertUser', signup.insertUser);
app.get('/signout', home.signout);
app.get('/connection', home.connection);
app.get('/loadConnections', home.loadConnections);
app.post('/editSummary', home.editSummary);
app.post('/editEducation', home.editEducation);
app.post('/addEducation', home.addEducation);
app.post('/deleteEducation', home.deleteEducation);
app.post('/editExperience', home.editExperience);
app.post('/addExperience', home.addExperience);
app.post('/deleteExperience', home.deleteExperience);
app.post('/editSkill', home.editSkill);
app.post('/addSkill', home.addSkill);
app.post('/deleteSkill', home.deleteSkill);
app.post('/acceptConnectionRequest', home.acceptConnectionRequest);
app.post('/rejectConnectionRequest', home.rejectConnectionRequest);
app.post('/searchMember', home.searchMember);
app.get('/showMember', home.showMember);
app.get('/showMemberProfile', home.showMemberProfile);
app.post('/sendRequest', home.sendRequest);



app.get('/api/session',function(req,res){
	
	if(req.session.userid){
		res.send(JSON.stringify({"response" : req.session.userid}));
	}
	else{
		res.send(JSON.stringify({"response" : "No Session Data to GET"}));
	}
});



http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
