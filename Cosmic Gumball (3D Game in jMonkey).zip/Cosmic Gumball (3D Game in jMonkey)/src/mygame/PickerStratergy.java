/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

/**
 *
 * @author KomalKishor
 */
public interface PickerStratergy {

    void pick() throws Exception;
}
