/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame;

/**
 *
 * @author KomalKishor
 */
public interface Observers {

    public abstract void update(String eventName);
}
