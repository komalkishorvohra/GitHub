package mygame;

/**
 *
 * @author KomalKishor
 */
public interface State {

    public void doAction(String name);
}
